-- MySQL dump 10.15  Distrib 10.0.21-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: corpblog
-- ------------------------------------------------------
-- Server version	10.0.21-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject_id` int(11) NOT NULL,
  `subject_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `activities_subject_id_index` (`subject_id`),
  KEY `activities_subject_type_index` (`subject_type`),
  KEY `activities_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (1,12,'App\\Article','created_article',1,'2015-12-11 18:05:45','2015-12-11 18:05:45'),(2,4,'App\\Comment','created_comment',1,'2015-12-11 18:17:27','2015-12-11 18:17:27'),(3,13,'App\\Article','created_article',2,'2015-12-11 18:32:34','2015-12-11 18:32:34'),(4,5,'App\\Comment','created_comment',2,'2015-12-11 18:32:54','2015-12-11 18:32:54'),(5,6,'App\\Comment','created_comment',2,'2015-12-11 18:33:00','2015-12-11 18:33:00'),(6,7,'App\\Comment','created_comment',2,'2015-12-11 18:33:10','2015-12-11 18:33:10'),(7,8,'App\\Comment','created_comment',1,'2015-12-11 19:08:21','2015-12-11 19:08:21'),(8,11,'App\\Article','updated_article',1,'2015-12-11 19:09:30','2015-12-11 19:09:30'),(9,9,'App\\Comment','created_comment',1,'2015-12-11 19:51:05','2015-12-11 19:51:05'),(10,14,'App\\Article','created_article',1,'2015-12-11 20:46:08','2015-12-11 20:46:08'),(11,14,'App\\Article','starred_article',1,'2015-12-13 15:01:16','2015-12-13 15:01:16'),(14,2,'App\\User','followed_user',1,'2015-12-13 15:35:32','2015-12-13 15:35:32'),(15,4,'App\\Comment','created_comment',1,'2015-12-13 15:44:02','2015-12-13 15:44:02');
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `category_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `articles_user_id_foreign` (`user_id`),
  KEY `articles_category_id_foreign` (`category_id`),
  CONSTRAINT `articles_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `articles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (3,2,'dsfdsf','sdfsdf','0000-00-00 00:00:00','0000-00-00 00:00:00',1),(4,1,'dsfdsf','sdfsdf','0000-00-00 00:00:00','0000-00-00 00:00:00',1),(5,2,'dsfdsf','sdfsdf','0000-00-00 00:00:00','0000-00-00 00:00:00',1),(6,1,'dsfdsf','sdfsdf','0000-00-00 00:00:00','0000-00-00 00:00:00',1),(7,2,'dsfdsf','sdfsdf','0000-00-00 00:00:00','0000-00-00 00:00:00',1),(8,1,'dsfdsf','sdfsdf','0000-00-00 00:00:00','0000-00-00 00:00:00',1),(9,2,'dsvds f ','fdsf sa ','2015-11-29 14:13:57','2015-11-29 14:13:57',1),(10,1,'article1','fdgdfgdfgdfg','2015-12-11 17:58:28','2015-12-11 17:58:28',1),(13,2,'admin\'s articles','line 1\r\nline 2\r\nline 3','2015-12-11 18:32:34','2015-12-11 18:32:34',1),(14,1,'new article','body  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\n\r\n====\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nvbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nvbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nbody  1\r\nv','2015-12-11 20:46:08','2015-12-11 20:49:16',1);
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'cat1','0000-00-00 00:00:00','0000-00-00 00:00:00',10);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `article_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `comments_article_id_foreign` (`article_id`),
  KEY `comments_user_id_foreign` (`user_id`),
  CONSTRAINT `comments_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,3,1,'das f asdf ','2015-12-10 20:01:25','2015-12-10 20:01:25'),(2,3,1,' asdf asdf ','2015-12-10 20:01:29','2015-12-10 20:01:29'),(3,9,1,'d asf s','2015-12-10 20:01:32','2015-12-10 20:01:32'),(4,14,1,'ds af das f','2015-12-13 15:44:02','2015-12-13 15:44:02');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1),('2015_11_01_162625_create_articles_table',1),('2015_11_03_204139_create_comments_table',1),('2015_11_03_213543_create_categories_table',1),('2015_11_03_213930_add_category_id_to_articles_table',1),('2015_11_21_121353_add_is_admin_flag_to_users_table',1),('2015_11_22_140241_add_order_field_to_categories_table',1),('2015_11_28_085143_create_user_follows_table',1),('2015_12_05_095040_create_views_table',2),('2015_12_05_125408_create_stars_table',2),('2015_12_11_175449_create_activities_table',3),('2015_12_11_212112_limit_article_title_lenght',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stars`
--

DROP TABLE IF EXISTS `stars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stars` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `article_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `stars_user_id_article_id_unique` (`user_id`,`article_id`),
  KEY `stars_article_id_foreign` (`article_id`),
  CONSTRAINT `stars_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stars_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stars`
--

LOCK TABLES `stars` WRITE;
/*!40000 ALTER TABLE `stars` DISABLE KEYS */;
INSERT INTO `stars` VALUES (1,9,1,'2015-12-10 20:01:05'),(2,14,1,'2015-12-13 15:01:16');
/*!40000 ALTER TABLE `stars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_follows`
--

DROP TABLE IF EXISTS `user_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follows` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `follower_id` int(10) unsigned NOT NULL,
  `followed_user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_follows_follower_id_followed_user_id_unique` (`follower_id`,`followed_user_id`),
  KEY `user_follows_followed_user_id_foreign` (`followed_user_id`),
  CONSTRAINT `user_follows_followed_user_id_foreign` FOREIGN KEY (`followed_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_follows_follower_id_foreign` FOREIGN KEY (`follower_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_follows`
--

LOCK TABLES `user_follows` WRITE;
/*!40000 ALTER TABLE `user_follows` DISABLE KEYS */;
INSERT INTO `user_follows` VALUES (6,2,1,'2015-11-29 14:22:00'),(22,2,3,'0000-00-00 00:00:00'),(23,2,4,'0000-00-00 00:00:00'),(25,1,4,'2015-11-29 15:26:17'),(34,1,2,'2015-12-13 15:35:32');
/*!40000 ALTER TABLE `user_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_admin` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Alex','litvinenko1706@gmail.com','$2y$10$wL7vAayuqRl2jOE23XF2ROqgOlpa9F8VPkc5OoqefS9jgf4T41KWi','POVE8dFCiGeEKm9g0Y1ThEB9HK4XSQT1VMFfI4im9081vUv71quTuAlNoS2L','2015-11-29 12:16:51','2015-11-29 12:16:57',0),(2,'Admin','admin@admin.com','$2y$10$9UzI5rXGziI1yr0sNN3ZRuJk0MY2B0H7QaK8Mp2PBi2/SVyiCSHxS','28gFgXeuKLJvdwkQMf4xRS2LkCV8V6h5nreS005ydLp35hJEYvJj7hRbSGVU','2015-11-29 12:17:21','2015-11-29 14:34:40',0),(3,'alexei','a@a.com','$2y$10$9UzI5rXGziI1yr0sNN3ZRuJk0MY2B0H7QaK8Mp2PBi2/SVyiCSHxS',NULL,'2015-11-29 12:17:21','2015-11-29 12:17:21',0),(4,'bogdan','b@b.com','$2y$10$9UzI5rXGziI1yr0sNN3ZRuJk0MY2B0H7QaK8Mp2PBi2/SVyiCSHxS',NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `views`
--

DROP TABLE IF EXISTS `views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `views` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `article_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `views_user_id_foreign` (`user_id`),
  KEY `views_article_id_foreign` (`article_id`),
  CONSTRAINT `views_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `views_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `views`
--

LOCK TABLES `views` WRITE;
/*!40000 ALTER TABLE `views` DISABLE KEYS */;
INSERT INTO `views` VALUES (1,9,1,'2015-12-10 20:01:09'),(2,3,1,'2015-12-10 20:01:11'),(3,4,1,'2015-12-10 20:01:13'),(4,4,1,'2015-12-10 20:01:15'),(16,13,1,'2015-12-11 19:50:54'),(17,13,NULL,'2015-12-11 20:54:55'),(20,13,1,'2015-12-11 21:21:01'),(21,14,1,'2015-12-13 15:43:54');
/*!40000 ALTER TABLE `views` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-12-13 20:11:47
