-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.0.17-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             8.3.0.4796
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for corpblog
DROP DATABASE IF EXISTS `corpblog`;
CREATE DATABASE IF NOT EXISTS `corpblog` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;
USE `corpblog`;


-- Dumping structure for table corpblog.articles
DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `category_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `articles_user_id_foreign` (`user_id`),
  KEY `articles_category_id_foreign` (`category_id`),
  CONSTRAINT `articles_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `articles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table corpblog.articles: ~0 rows (approximately)
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` (`id`, `user_id`, `title`, `body`, `created_at`, `updated_at`, `category_id`) VALUES
	(3, 2, 'dsfdsf', 'sdfsdf', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
	(4, 1, 'dsfdsf', 'sdfsdf', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
	(5, 2, 'dsfdsf', 'sdfsdf', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
	(6, 1, 'dsfdsf', 'sdfsdf', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
	(7, 2, 'dsfdsf', 'sdfsdf', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
	(8, 1, 'dsfdsf', 'sdfsdf', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
	(9, 2, 'dsvds f ', 'fdsf sa ', '2015-11-29 16:13:57', '2015-11-29 16:13:57', 1);
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;


-- Dumping structure for table corpblog.categories
DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table corpblog.categories: ~0 rows (approximately)
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`, `order`) VALUES
	(1, 'cat1', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 10);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;


-- Dumping structure for table corpblog.comments
DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `article_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `comments_article_id_foreign` (`article_id`),
  KEY `comments_user_id_foreign` (`user_id`),
  CONSTRAINT `comments_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table corpblog.comments: ~0 rows (approximately)
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;


-- Dumping structure for table corpblog.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table corpblog.migrations: ~9 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`migration`, `batch`) VALUES
	('2014_10_12_000000_create_users_table', 1),
	('2014_10_12_100000_create_password_resets_table', 1),
	('2015_11_01_162625_create_articles_table', 1),
	('2015_11_03_204139_create_comments_table', 1),
	('2015_11_03_213543_create_categories_table', 1),
	('2015_11_03_213930_add_category_id_to_articles_table', 1),
	('2015_11_21_121353_add_is_admin_flag_to_users_table', 1),
	('2015_11_22_140241_add_order_field_to_categories_table', 1),
	('2015_11_28_085143_create_user_follows_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;


-- Dumping structure for table corpblog.password_resets
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table corpblog.password_resets: ~0 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;


-- Dumping structure for table corpblog.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_admin` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table corpblog.users: ~2 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `is_admin`) VALUES
	(1, 'Alex', 'litvinenko1706@gmail.com', '$2y$10$wL7vAayuqRl2jOE23XF2ROqgOlpa9F8VPkc5OoqefS9jgf4T41KWi', 'POVE8dFCiGeEKm9g0Y1ThEB9HK4XSQT1VMFfI4im9081vUv71quTuAlNoS2L', '2015-11-29 14:16:51', '2015-11-29 14:16:57', 0),
	(2, 'Admin', 'admin@admin.com', '$2y$10$9UzI5rXGziI1yr0sNN3ZRuJk0MY2B0H7QaK8Mp2PBi2/SVyiCSHxS', '28gFgXeuKLJvdwkQMf4xRS2LkCV8V6h5nreS005ydLp35hJEYvJj7hRbSGVU', '2015-11-29 14:17:21', '2015-11-29 16:34:40', 0),
	(3, 'alexei', 'a@a.com', '$2y$10$9UzI5rXGziI1yr0sNN3ZRuJk0MY2B0H7QaK8Mp2PBi2/SVyiCSHxS', NULL, '2015-11-29 14:17:21', '2015-11-29 14:17:21', 0),
	(4, 'bogdan', 'b@b.com', '$2y$10$9UzI5rXGziI1yr0sNN3ZRuJk0MY2B0H7QaK8Mp2PBi2/SVyiCSHxS', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;


-- Dumping structure for table corpblog.user_follows
DROP TABLE IF EXISTS `user_follows`;
CREATE TABLE IF NOT EXISTS `user_follows` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `follower_id` int(10) unsigned NOT NULL,
  `followed_user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_follows_follower_id_followed_user_id_unique` (`follower_id`,`followed_user_id`),
  KEY `user_follows_followed_user_id_foreign` (`followed_user_id`),
  CONSTRAINT `user_follows_followed_user_id_foreign` FOREIGN KEY (`followed_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_follows_follower_id_foreign` FOREIGN KEY (`follower_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table corpblog.user_follows: ~0 rows (approximately)
/*!40000 ALTER TABLE `user_follows` DISABLE KEYS */;
INSERT INTO `user_follows` (`id`, `follower_id`, `followed_user_id`, `created_at`) VALUES
	(6, 2, 1, '2015-11-29 16:22:00'),
	(22, 2, 3, '0000-00-00 00:00:00'),
	(23, 2, 4, '0000-00-00 00:00:00'),
	(25, 1, 4, '2015-11-29 17:26:17');
/*!40000 ALTER TABLE `user_follows` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
