@extends('layouts.default')

@section('content')

<h1 class="text-center">Sorry, you don't have access to this page</h1>

@stop

